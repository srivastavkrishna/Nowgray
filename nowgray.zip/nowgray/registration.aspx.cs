﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Globalization;

public partial class registration : System.Web.UI.Page
{
    string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
    string today = DateTime.Now.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

        }
    }
    protected void insert()
    {
        string strname;
        SqlConnection con = new SqlConnection(constr);
        con.Open();
        SqlCommand cmd = new SqlCommand("sp_curd", con);  // Here  we used stored procedure..
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@action", "insert"); // This is action field for execute the single query.
        cmd.Parameters.AddWithValue("@name", txtname.Text);
        cmd.Parameters.AddWithValue("@email", txtemail.Text);
        cmd.Parameters.AddWithValue("@contactno", txtconno.Text);
        cmd.Parameters.AddWithValue("@gender", rdbgender.SelectedItem.Text);
        cmd.Parameters.AddWithValue("@city", ddlcity.SelectedValue);
        cmd.Parameters.AddWithValue("@address", txtaddress.Text);
        cmd.Parameters.AddWithValue("@status", "active");
        cmd.Parameters.AddWithValue("@createddate", today);

        if (img.HasFile)
        {
            strname = img.FileName.ToString();
            img.PostedFile.SaveAs(Server.MapPath("~/img/") + strname);
            cmd.Parameters.AddWithValue("@image", strname);
        }

        int n = cmd.ExecuteNonQuery();
        if (n > 0)
        {
            Response.Write("<script>alert('Registeration Successfully.')</script>");
            clear();
        }
        else
        {
            Response.Write("<script>alert('Technical Error.')</script>");
        }
        con.Close();
    }

    
    public void clear() // This is the clear method for clear data after save data.
    {
        txtname.Text = "";
        txtaddress.Text = "";
        txtconno.Text = "";
        txtemail.Text = "";
        ddlcity.SelectedIndex = -1;
        rdbgender.ClearSelection();
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        insert();
    }

    protected void txtemail_TextChanged(object sender, EventArgs e)
    {
        checkemail();
    }

    protected void txtconno_TextChanged(object sender, EventArgs e)
    {
        checknumber();
    }
    protected void checkemail() // This method is used to check the email that is already exits or not
    {
        SqlConnection con = new SqlConnection(constr);
        con.Open();
        SqlCommand cmd = new SqlCommand("sp_curd", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@action", "checkemail");
        cmd.Parameters.AddWithValue("@email", txtemail.Text);
        cmd.Parameters.AddWithValue("@status", "active");

        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            lblemail.Visible = true;
            lblemail.Text = "Email is already exist.";
        }
        else
        {
            lblemail.Visible = false;
        }
        con.Close();
    }
    protected void checknumber() // This method is used to check the number that is already exits or not
    {
        SqlConnection con = new SqlConnection(constr);
        con.Open();
        SqlCommand cmd = new SqlCommand("sp_curd", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@action", "checknumber");
        cmd.Parameters.AddWithValue("@contactno", txtconno.Text);
        cmd.Parameters.AddWithValue("@status", "active");

        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            lblconno.Visible = true;
            lblconno.Text = "Contact Number is already exist.";
        }
        else
        {
            lblconno.Visible = false;
        }
        con.Close();
    }
}