﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class view_details : System.Web.UI.Page
{
    string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
    string id;
    protected void Page_Load(object sender, EventArgs e)
    {
        id = Request.QueryString["id"];
        if (!IsPostBack)
        {

            if (id != null)
            {
                showdetails();
            }
            else
            {
                Response.Redirect("view-all-details.aspx");
            }
        }
    }
    protected void showdetails() // This method used to show all data of perticular single  id
    {
        SqlConnection con = new SqlConnection(constr);
        con.Open();
        SqlCommand cmd = new SqlCommand("sp_curd", con); // Here  we used stored procedure..
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@action", "selectdetails"); // This is action field for execute the single query.
        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@status", "active");
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            lblname.InnerText = dr["name"].ToString();
            lblemail.InnerText = dr["email"].ToString();
            lblconno.InnerText = dr["contactno"].ToString();
            lblgen.InnerText = dr["gender"].ToString();
            lblcity.InnerText = dr["city"].ToString();
            lbladdress.InnerText = dr["address"].ToString();
            img.ImageUrl = "~/img/" + dr["image"].ToString();
        }
        con.Close();
    }

    protected void btnback_Click(object sender, EventArgs e)
    {
        Response.Redirect("view-all-details.aspx");
    }
}