﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class update : System.Web.UI.Page
{
    string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
    string id;
    protected void Page_Load(object sender, EventArgs e)
    {
        id = Request.QueryString["id"];
        if (!IsPostBack)
        {

            if (id != null)
            {
                showdetails();
            }

            else
            {
                Response.Redirect("view-all-details.aspx");
            }
        }

    }

    protected void showdetails() // This method used to show all data of perticular single  id
    {
        SqlConnection con = new SqlConnection(constr);
        con.Open();
        SqlCommand cmd = new SqlCommand("sp_curd", con);  // Here  we used stored procedure..
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@action", "selectdetails"); // This is action field for execute the single query.
        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@status", "active");
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            txtname.Text = dr["name"].ToString();
            txtaddress.Text = dr["address"].ToString();
            txtemail.Text = dr["email"].ToString();
            txtconno.Text = dr["contactno"].ToString();
            rdbgender.SelectedValue = dr["gender"].ToString();
            ddlcity.SelectedValue = dr["city"].ToString();
        }
        con.Close();
    }

    protected void txtemail_TextChanged(object sender, EventArgs e) // This is the textchanged method
    {
        checkemail();
    }

    protected void txtconno_TextChanged(object sender, EventArgs e) // This is the textchanged method
    {
        checknumber();
    }
    protected void checkemail() // This method is used to check the email that is already exits or not
    {
        SqlConnection con = new SqlConnection(constr);
        con.Open();
        SqlCommand cmd = new SqlCommand("sp_curd", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@action", "checkemail");
        cmd.Parameters.AddWithValue("@email", txtemail.Text);
        cmd.Parameters.AddWithValue("@status", "active");

        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            lblemail.Visible = true;
            lblemail.Text = "Email is already exist.";
        }
        else
        {
            lblemail.Visible = false;
        }
        con.Close();
    }
    protected void checknumber() // This method is used to check the number that is already exits or not
    {
        SqlConnection con = new SqlConnection(constr);
        con.Open();
        SqlCommand cmd = new SqlCommand("sp_curd", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@action", "checknumber");
        cmd.Parameters.AddWithValue("@contactno", txtconno.Text);
        cmd.Parameters.AddWithValue("@status", "active");

        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            lblconno.Visible = true;
            lblconno.Text = "Contact Number is already exist.";
        }
        else
        {
            lblconno.Visible = false;
        }
        con.Close();
    }

    protected void Update_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(constr);
        con.Open();
        SqlCommand cmd = new SqlCommand("sp_curd", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@action", "update");
        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@name", txtname.Text);
        cmd.Parameters.AddWithValue("@email", txtemail.Text);
        cmd.Parameters.AddWithValue("@contactno", txtconno.Text);
        cmd.Parameters.AddWithValue("@gender", rdbgender.SelectedValue);
        cmd.Parameters.AddWithValue("@city", ddlcity.SelectedValue);
        cmd.Parameters.AddWithValue("@address", txtaddress.Text);
        int n = cmd.ExecuteNonQuery();
        if (n > 0)
        {
            Response.Write("<script>alert('Registration Details Updated')</script>");
            showdetails();
        }
        else
        {
            Response.Write("<script>alert('Technical Error')</script>");
        }
        con.Close();
    }

    protected void btnback_Click(object sender, EventArgs e)
    {
        Response.Redirect("view-all-details.aspx");
    }
}