﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class view_registration_details : System.Web.UI.Page
{
    string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        string id = Request.QueryString["id"];
        Session["id"] = id;
        showdetails();
    }

    protected void showdetails()
    {
        SqlConnection con = new SqlConnection(constr);
        con.Open();
        SqlCommand cmd = new SqlCommand("sp_curd", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@action", "selectdetails");
        cmd.Parameters.AddWithValue("@id", Session["id"].ToString());
        cmd.Parameters.AddWithValue("@status", "active");
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            txtname.Text = dr["name"].ToString();
            txtaddress.Text = dr["address"].ToString();
            txtemail.Text = dr["email"].ToString();
            txtconno.Text = dr["contactno"].ToString();
            rdbgender.SelectedValue = dr["gender"].ToString();
            ddlcity.SelectedValue = dr["city"].ToString();
        }
        con.Close();
    }

    protected void txtemail_TextChanged(object sender, EventArgs e)
    {
        checkemail();
    }

    protected void txtconno_TextChanged(object sender, EventArgs e)
    {
        checknumber();
    }
    protected void checkemail()
    {
        SqlConnection con = new SqlConnection(constr);
        con.Open();
        SqlCommand cmd = new SqlCommand("sp_curd", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@action", "checkemail");
        cmd.Parameters.AddWithValue("@email", txtemail.Text);
        cmd.Parameters.AddWithValue("@status", "active");

        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            lblemail.Visible = true;
            lblemail.Text = "Email is already exist.";
        }
        else
        {
            lblemail.Visible = false;
        }
        con.Close();
    }
    protected void checknumber()
    {
        SqlConnection con = new SqlConnection(constr);
        con.Open();
        SqlCommand cmd = new SqlCommand("sp_curd", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@action", "checknumber");
        cmd.Parameters.AddWithValue("@contactno", txtconno.Text);
        cmd.Parameters.AddWithValue("@status", "active");

        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            lblconno.Visible = true;
            lblconno.Text = "Contact Number is already exist.";
        }
        else
        {
            lblconno.Visible = false;
        }
        con.Close();
    }

    protected void Update_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(constr);
        con.Open();
        SqlCommand cmd = new SqlCommand("sp_curd", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@action", "update");
        cmd.Parameters.AddWithValue("@id", Session["id"].ToString());
        cmd.Parameters.AddWithValue("@name", txtname.Text);
        cmd.Parameters.AddWithValue("@email", txtemail.Text);
        cmd.Parameters.AddWithValue("@contactno", txtconno.Text);
        cmd.Parameters.AddWithValue("@gender", rdbgender.SelectedValue);
        cmd.Parameters.AddWithValue("@city", ddlcity.SelectedValue);
        cmd.Parameters.AddWithValue("@address", txtaddress.Text);
        int n = cmd.ExecuteNonQuery();
        if (n > 0)
        {
            Response.Write("<script>alert('Registration Details Updated')</script>");
        }
        else
        {
            Response.Write("<script>alert('Technical Error')</script>");
        }
        con.Close();
    }
}