﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Globalization;

public partial class view_all_details : System.Web.UI.Page
{
    string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
    string today = DateTime.Now.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            binddata();
        }
    }

    protected void binddata() // Here we bind  all the data of registration details
    {
        SqlConnection con = new SqlConnection(constr);
        con.Open();
        SqlCommand cmd = new SqlCommand("sp_curd", con); // Here  we used stored procedure..
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@action", "alldetails"); // This is action field for execute the single query.
        cmd.Parameters.AddWithValue("@status", "active");
        SqlDataAdapter sda = new SqlDataAdapter(cmd);
        cmd.Connection = con;
        sda.SelectCommand = cmd;
        DataSet dt = new DataSet();
        sda.Fill(dt);
        gdvreg.DataSource = dt;
        gdvreg.DataBind();
        con.Close();
    }

    protected void gdvreg_RowCommand(object sender, GridViewCommandEventArgs e)  // This is Row Command Method
    {
        if (e.CommandName == "Delete")
        {
            GridViewRow gvr = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
            int rowIndex = gvr.RowIndex; // Take the RowIndex
            int id = Convert.ToInt32(e.CommandArgument); // Take the id from command Argument
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand cmd = new SqlCommand("sp_curd", con); // Here  we used stored procedure..
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@action", "delete"); // This is action field for execute the single query.
            cmd.Parameters.AddWithValue("@id", id);
            cmd.Parameters.AddWithValue("@status", "deactive");
            int n = cmd.ExecuteNonQuery();
            con.Close();
            binddata();
        }
        if (e.CommandName == "Edit")
        {
            GridViewRow gvr = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
            int rowIndex = gvr.RowIndex; // Take the RowIndex
            int id = Convert.ToInt32(e.CommandArgument); // Take the id from command Argument.
            GridViewRow row = gdvreg.Rows[rowIndex];
            Response.Redirect("update.aspx?id=" + id + ""); // Redirect update.aspx page with all details of this id..

        }

        if (e.CommandName == "View")
        {
            GridViewRow gvr = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
            int rowIndex = gvr.RowIndex; // Take the RowIndex
            int id = Convert.ToInt32(e.CommandArgument); // Take the id from command Argument.
            GridViewRow row = gdvreg.Rows[rowIndex];
            Response.Redirect("view-details.aspx?id=" + id + ""); // Redirect view-details.aspx page with all details of this id..

        }
    }

    protected void gdvreg_RowDeleting(object sender, GridViewDeleteEventArgs e) // This is row deleting  function..
    {

    }

    protected void gdvreg_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdvreg.PageIndex = e.NewPageIndex;
        this.binddata();
    }

    protected void btnback_Click(object sender, EventArgs e)
    {
        Response.Redirect("registration.aspx");
    }
}